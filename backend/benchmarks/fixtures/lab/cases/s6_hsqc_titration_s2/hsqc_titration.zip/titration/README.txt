Sparky peak lists of a 15N-HSQC titration. Protein 100 uM throughout (volume change negligible).
Lk_XXXXuM.list = titration point k at XXXX uM total ligand. w1 = 15N (ppm), w2 = 1H (ppm).
